﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        
            this.IsMdiContainer = true;

            this.MainMenu.Dock = DockStyle.Left;



        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void asdasdToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }


    }
}
